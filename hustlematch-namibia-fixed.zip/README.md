# 🚀 HustleMatch Namibia

**Find Your Perfect Side Hustle** — 120+ ideas matched to your skills, time, and budget.

---

## 📦 Quick Deploy to Vercel

### **Option 1: Direct Vercel Deployment (Easiest)**

1. **Go to:** https://vercel.com/new
2. **Click:** "Create Git Repository" → Choose GitHub/GitLab/Gitea
3. **Upload this folder** to GitHub
4. **Vercel auto-deploys** — your site is live in <1 minute!

### **Option 2: Vercel CLI**

```bash
# Install Vercel CLI
npm install -g vercel

# In the project folder
vercel

# Follow the prompts
```

---

## 🎯 What's Included

✅ **120+ Hustle Ideas** across 9 categories:
- 💻 Digital Services
- 🛍️ Sales & Ecommerce
- 💄 Beauty Industry
- 🎯 Coaching & Education
- ✈️ Tourism & Travel
- 🚗 Transport & Mobility
- ⚡ Energy & Water
- 🎬 Creative & Media
- 🌾 & More

✅ **Features:**
- 8-question smart quiz
- Personalized hustle matching
- Step-by-step action plans
- Manual admin approval system
- Payment integration (PayToday)
- Mobile-responsive design
- White background, professional look

---

## 💰 Payment Link

Your PayToday payment link is integrated and ready to accept N$50 payments.

---

## 🔧 Setup Instructions

### **Local Development**
```bash
# Install dependencies
npm install

# Start dev server
npm start

# Open http://localhost:3000
```

### **Build for Production**
```bash
npm run build
```

---

## 📱 Admin Dashboard

- **URL:** Click "Admin" button in nav
- **Password:** `hustleadmin2025` (change this in production!)
- **Features:**
  - View all users (approved, pending, rejected)
  - Approve/reject payments
  - View revenue stats
  - Export user data to CSV

---

## 🔐 Important Before Launch

1. **Change Admin Password:**
   - Open `HustleMatchNamibia.jsx`
   - Search for `hustleadmin2025`
   - Replace with your secure password

2. **Update PayToday Link:**
   - Already set to your payment URL
   - Test it before going live

3. **Enable Database (Optional):**
   - Currently uses browser localStorage
   - For production, connect to Firebase/Supabase
   - Data will persist across sessions

---

## 📊 Quiz Categories

Users answer 8 quick questions:
1. What are your top skills?
2. When are you available?
3. What's your starting budget?
4. Where do you prefer to work?
5. Which category interests you?

Then they get **3 personalized hustle matches** with:
- Step-by-step setup guide
- 7-day action plan
- Cost breakdown
- Difficulty level

---

## 🌐 Live Demo Features

**Home Page:**
- Hero section with CTA
- Categories showcase (120+ ideas)
- Promo banner (Limited time: N$100 → N$50)
- Feature cards
- Disclaimer

**Payment Page:**
- PayToday integration
- Manual approval pending message
- Step-by-step instructions

**Quiz Page:**
- Progress bar
- Smart matching algorithm
- Personalized scoring

**Results Page:**
- Top 3 matches
- Expandable cards
- Action plans & tips
- One-time use tracking

**Admin Dashboard:**
- User management
- Payment approval/rejection
- Stats & analytics
- CSV export

---

## 📈 Next Steps

1. **Deploy to Vercel** (5 minutes)
2. **Test payment link** with test transaction
3. **Share the live URL** with your audience
4. **Monitor admin dashboard** for incoming payments
5. **Approve/reject users** manually

---

## 🆘 Support

If you need changes:
- Update any hustle ideas in the HUSTLES array
- Modify quiz questions
- Change colors/fonts
- Add new features

---

## 📜 License

© 2026 HustleMatch Namibia. All rights reserved.

**Ready to launch?** → https://vercel.com/new

---

**Questions?** Just ask! 🚀
