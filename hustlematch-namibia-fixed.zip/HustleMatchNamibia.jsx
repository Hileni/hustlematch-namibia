import { useState, useEffect } from "react";

// ── Hustle Database (ordered: Digital → Sales → Beauty → Coaching → Others) ──
const HUSTLES = [

  // ── DIGITAL SERVICES ────────────────────────────────────────────────────────
  { id:1,  name:"Social Media Management", tags:["marketing","remote","creative","digital"], cost:"N$0–200", difficulty:"Easy", budget:200, skills:["social media","writing","digital"], time:"flexible" },
  { id:2,  name:"Freelance Graphic Design", tags:["creative","tech","remote","digital"], cost:"N$0–500", difficulty:"Medium", budget:500, skills:["design","computer","digital"], time:"flexible" },
  { id:3,  name:"App / Website Development", tags:["tech","remote","digital"], cost:"N$0–500", difficulty:"Hard", budget:500, skills:["coding","tech","digital"], time:"flexible" },
  { id:4,  name:"Content Creation (TikTok / YouTube)", tags:["creative","digital","remote"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["video","creative","social media"], time:"flexible" },
  { id:5,  name:"Virtual Assistant Services", tags:["remote","admin","digital"], cost:"N$0–200", difficulty:"Easy", budget:200, skills:["admin","computer","digital"], time:"flexible" },
  { id:6,  name:"Freelance Writing & Blogging", tags:["writing","remote","creative","digital"], cost:"N$0–100", difficulty:"Easy", budget:100, skills:["writing","research","digital"], time:"flexible" },
  { id:7,  name:"Podcast Production & Editing", tags:["audio","creative","remote","digital"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["audio","creative","digital"], time:"flexible" },
  { id:8,  name:"Data Entry & Transcription", tags:["remote","admin","digital"], cost:"N$0", difficulty:"Easy", budget:0, skills:["computer","typing","digital"], time:"flexible" },
  { id:9,  name:"Email Marketing Services", tags:["marketing","remote","digital"], cost:"N$0–300", difficulty:"Medium", budget:300, skills:["marketing","writing","digital"], time:"flexible" },
  { id:10, name:"Online Surveys & Micro Tasks", tags:["digital","remote","easy"], cost:"N$0", difficulty:"Easy", budget:0, skills:["computer","basic","digital"], time:"flexible" },
  { id:11, name:"SEO & Digital Marketing Consultant", tags:["marketing","remote","digital","tech"], cost:"N$0–500", difficulty:"Hard", budget:500, skills:["marketing","digital","tech"], time:"flexible" },
  { id:12, name:"Printing & Graphic Design Services", tags:["creative","local","tech","digital"], cost:"N$2000–5000", difficulty:"Medium", budget:5000, skills:["design","tech","digital"], time:"flexible" },

  // ── SALES & ECOMMERCE ────────────────────────────────────────────────────────
  { id:13, name:"Dropshipping Store", tags:["ecommerce","remote","sales","digital"], cost:"N$500–1500", difficulty:"Hard", budget:1500, skills:["marketing","sales","tech"], time:"flexible" },
  { id:14, name:"Reselling — Thrift / Online", tags:["ecommerce","local","sales"], cost:"N$500–2000", difficulty:"Easy", budget:2000, skills:["sales","marketing"], time:"weekends" },
  { id:15, name:"Phone Cases & Accessories Selling", tags:["ecommerce","local","sales"], cost:"N$500–2000", difficulty:"Easy", budget:2000, skills:["sales","marketing"], time:"weekends" },
  { id:16, name:"WhatsApp / Facebook Marketplace Seller", tags:["sales","local","ecommerce"], cost:"N$200–1000", difficulty:"Easy", budget:1000, skills:["sales","social media"], time:"flexible" },
  { id:17, name:"Import & Resell Products (China / SA)", tags:["sales","ecommerce","import"], cost:"N$2000–8000", difficulty:"Medium", budget:8000, skills:["sales","import","marketing"], time:"flexible" },
  { id:18, name:"Hair Weave & Extensions Supply", tags:["beauty","sales","local","ecommerce"], cost:"N$1000–5000", difficulty:"Easy", budget:5000, skills:["beauty","sales","hair"], time:"flexible" },
  { id:19, name:"Sell Beauty Products (Reseller)", tags:["beauty","ecommerce","local","sales"], cost:"N$500–3000", difficulty:"Easy", budget:3000, skills:["sales","beauty","marketing"], time:"flexible" },
  { id:20, name:"Beauty Supply Online Store", tags:["beauty","ecommerce","remote","sales","digital"], cost:"N$1000–5000", difficulty:"Medium", budget:5000, skills:["beauty","sales","digital"], time:"flexible" },
  { id:21, name:"Real Estate Referral Agent", tags:["sales","local","professional"], cost:"N$0–500", difficulty:"Hard", budget:500, skills:["sales","communication"], time:"flexible" },
  { id:22, name:"Airbnb / Short-Term Room Rental", tags:["property","local","sales","passive"], cost:"N$1000+", difficulty:"Medium", budget:1000, skills:["hosting","communication"], time:"flexible" },
  { id:23, name:"Homemade Food & Baked Goods Sales", tags:["food","local","sales"], cost:"N$300–1000", difficulty:"Easy", budget:1000, skills:["cooking","baking","sales"], time:"weekends" },
  { id:24, name:"Homemade Juice & Beverages", tags:["food","local","health","sales"], cost:"N$300–800", difficulty:"Easy", budget:800, skills:["cooking","sales"], time:"mornings" },

  // ── BEAUTY INDUSTRY ──────────────────────────────────────────────────────────
  { id:25, name:"Nail Technician (Nails at Home)", tags:["beauty","local","service"], cost:"N$500–2000", difficulty:"Easy", budget:2000, skills:["beauty","nails","hands-on"], time:"flexible" },
  { id:26, name:"Nail Art & Custom Nail Designs", tags:["beauty","creative","local"], cost:"N$300–1500", difficulty:"Easy", budget:1500, skills:["beauty","nails","art"], time:"flexible" },
  { id:27, name:"Eyelash Extensions & Lash Business", tags:["beauty","local","service"], cost:"N$800–3000", difficulty:"Medium", budget:3000, skills:["beauty","lashes","hands-on"], time:"flexible" },
  { id:28, name:"Makeup Artist (MUA)", tags:["beauty","local","creative","events"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["beauty","makeup","creative"], time:"weekends" },
  { id:29, name:"Bridal Hair & Beauty Packages", tags:["beauty","events","local","service"], cost:"N$1000–4000", difficulty:"Medium", budget:4000, skills:["beauty","hair","makeup"], time:"weekends" },
  { id:30, name:"Open a Home Salon", tags:["beauty","local","service"], cost:"N$2000–8000", difficulty:"Medium", budget:8000, skills:["beauty","hair","business"], time:"full-time" },
  { id:31, name:"Hair Braiding & Styling", tags:["beauty","local","service"], cost:"N$200–1000", difficulty:"Medium", budget:1000, skills:["beauty","hair","hands-on"], time:"flexible" },
  { id:32, name:"Eyebrow Threading & Shaping", tags:["beauty","local","service"], cost:"N$200–1000", difficulty:"Easy", budget:1000, skills:["beauty","hands-on"], time:"flexible" },
  { id:33, name:"Waxing & Hair Removal Services", tags:["beauty","local","service"], cost:"N$1000–3000", difficulty:"Medium", budget:3000, skills:["beauty","hands-on"], time:"flexible" },
  { id:34, name:"Body Massage & Relaxation Therapy", tags:["beauty","health","local","service"], cost:"N$1000–4000", difficulty:"Medium", budget:4000, skills:["beauty","health","hands-on"], time:"flexible" },
  { id:35, name:"Mobile Beauty Therapist (Home Visits)", tags:["beauty","local","service"], cost:"N$500–2000", difficulty:"Easy", budget:2000, skills:["beauty","hands-on","driving"], time:"flexible" },
  { id:36, name:"Skincare Routine Consultant", tags:["beauty","remote","health","local"], cost:"N$0–500", difficulty:"Easy", budget:500, skills:["beauty","skincare","social media"], time:"flexible" },
  { id:37, name:"Handmade Natural Skincare Products", tags:["beauty","crafts","local","ecommerce"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["beauty","skincare","crafts"], time:"weekends" },
  { id:38, name:"Pedicure & Foot Care Services", tags:["beauty","local","service","health"], cost:"N$300–1500", difficulty:"Easy", budget:1500, skills:["beauty","hands-on"], time:"flexible" },
  { id:39, name:"Beauty & Glam TikTok / YouTube", tags:["beauty","creative","digital","remote"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["beauty","video","social media"], time:"flexible" },
  { id:40, name:"Beauty Influencer & Brand Deals", tags:["beauty","digital","remote","marketing"], cost:"N$0–500", difficulty:"Medium", budget:500, skills:["beauty","social media","creative"], time:"flexible" },
  { id:41, name:"Import & Sell Beauty Products", tags:["beauty","ecommerce","sales","import"], cost:"N$2000–10000", difficulty:"Hard", budget:10000, skills:["sales","import","beauty"], time:"flexible" },
  { id:42, name:"Natural Hair Care Coaching", tags:["beauty","education","remote","local","coaching"], cost:"N$0–500", difficulty:"Easy", budget:500, skills:["beauty","hair","coaching"], time:"flexible" },

  // ── COACHING & EDUCATION ─────────────────────────────────────────────────────
  { id:43, name:"Life Coach (Online / In-Person)", tags:["coaching","remote","local","education"], cost:"N$0–500", difficulty:"Medium", budget:500, skills:["coaching","communication","teaching"], time:"flexible" },
  { id:44, name:"Business Start-Up Coach", tags:["coaching","remote","local","education"], cost:"N$0–500", difficulty:"Medium", budget:500, skills:["coaching","business","communication"], time:"flexible" },
  { id:45, name:"Fitness & Wellness Coach", tags:["coaching","health","local","remote"], cost:"N$200–800", difficulty:"Medium", budget:800, skills:["fitness","coaching","health"], time:"mornings" },
  { id:46, name:"Personal Finance Coach", tags:["coaching","remote","education"], cost:"N$0–300", difficulty:"Medium", budget:300, skills:["coaching","finance","communication"], time:"flexible" },
  { id:47, name:"Academic Tutoring & Coaching", tags:["education","coaching","remote","local"], cost:"N$0–100", difficulty:"Easy", budget:100, skills:["teaching","coaching","education"], time:"evenings" },
  { id:48, name:"Online Tutoring via Zoom / Google Meet", tags:["education","coaching","remote"], cost:"N$0–200", difficulty:"Easy", budget:200, skills:["teaching","tech","coaching"], time:"evenings" },
  { id:49, name:"Social Media Coaching for Businesses", tags:["coaching","marketing","remote","digital"], cost:"N$0–300", difficulty:"Medium", budget:300, skills:["coaching","social media","marketing"], time:"flexible" },
  { id:50, name:"Career Coaching & CV Writing", tags:["coaching","remote","professional"], cost:"N$0–300", difficulty:"Medium", budget:300, skills:["coaching","writing","communication"], time:"flexible" },
  { id:51, name:"Parenting & Family Coach", tags:["coaching","local","remote","service"], cost:"N$0–300", difficulty:"Medium", budget:300, skills:["coaching","care","communication"], time:"flexible" },
  { id:52, name:"Music Lessons (Guitar, Piano, Vocals)", tags:["music","education","coaching","local"], cost:"N$0–500", difficulty:"Medium", budget:500, skills:["music","teaching","coaching"], time:"evenings" },
  { id:53, name:"Mindset & Motivation Coaching", tags:["coaching","remote","education"], cost:"N$0–300", difficulty:"Medium", budget:300, skills:["coaching","communication","creative"], time:"flexible" },
  { id:54, name:"Side Hustle Coaching (Help Others)", tags:["coaching","remote","local","education"], cost:"N$0–200", difficulty:"Easy", budget:200, skills:["coaching","business","communication"], time:"flexible" },

  // ── OTHER HUSTLES ────────────────────────────────────────────────────────────
  { id:55, name:"Photography & Videography", tags:["creative","events","local"], cost:"N$2000–5000", difficulty:"Medium", budget:5000, skills:["photography","design"], time:"weekends" },
  { id:56, name:"Event Planning & Coordination", tags:["events","local","social"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["organization","social"], time:"weekends" },
  { id:57, name:"Cleaning Services", tags:["local","physical","service"], cost:"N$200–500", difficulty:"Easy", budget:500, skills:["physical","service"], time:"flexible" },
  { id:58, name:"Car Washing & Detailing", tags:["local","physical","service"], cost:"N$500–1500", difficulty:"Easy", budget:1500, skills:["physical","service"], time:"weekends" },
  { id:59, name:"Delivery & Courier Service", tags:["physical","local","transport"], cost:"N$1000–3000", difficulty:"Easy", budget:3000, skills:["driving","physical"], time:"flexible" },
  { id:60, name:"Clothing Alterations & Tailoring", tags:["crafts","local","creative"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["sewing","crafts"], time:"flexible" },
  { id:61, name:"Candle & Soap Making", tags:["crafts","creative","local"], cost:"N$300–800", difficulty:"Easy", budget:800, skills:["crafts","creative"], time:"weekends" },
  { id:62, name:"Embroidery & Custom Clothing", tags:["crafts","creative","local"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["sewing","crafts"], time:"flexible" },
  { id:63, name:"Mobile Phone Repairs", tags:["tech","local","hands-on"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["tech","hands-on"], time:"part-time" },
  { id:64, name:"Vegetable Garden & Sales", tags:["agriculture","local"], cost:"N$200–800", difficulty:"Easy", budget:800, skills:["gardening","sales"], time:"flexible" },
  { id:65, name:"Poultry (Chicken) Farming", tags:["agriculture","local"], cost:"N$1000–5000", difficulty:"Medium", budget:5000, skills:["farming","animal care"], time:"full-time" },
  { id:66, name:"Mushroom Farming", tags:["agriculture","local","innovative"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["farming","science"], time:"flexible" },
  { id:67, name:"Herb & Spice Growing", tags:["agriculture","local","creative"], cost:"N$200–600", difficulty:"Easy", budget:600, skills:["gardening","cooking"], time:"flexible" },
  { id:68, name:"Childcare / Babysitting", tags:["service","local","care"], cost:"N$0–200", difficulty:"Easy", budget:200, skills:["care","patience"], time:"flexible" },
  { id:69, name:"Furniture Making & Repairs", tags:["crafts","physical","local"], cost:"N$1000–3000", difficulty:"Hard", budget:3000, skills:["carpentry","physical"], time:"flexible" },
  { id:70, name:"Shoe Repair & Cleaning", tags:["local","service","hands-on"], cost:"N$500–1500", difficulty:"Easy", budget:1500, skills:["hands-on","service"], time:"flexible" },
  { id:71, name:"Painting & Wall Art", tags:["creative","local","art"], cost:"N$200–1000", difficulty:"Medium", budget:1000, skills:["art","creative"], time:"weekends" },
  { id:72, name:"Translation Services", tags:["language","remote","writing"], cost:"N$0–100", difficulty:"Easy", budget:100, skills:["language","writing"], time:"flexible" },

  // ── AI & AUTOMATION SERVICES ────────────────────────────────────────────────
  { id:73, name:"ChatGPT & AI Prompt Consultant", tags:["ai","remote","digital"], cost:"N$0–300", difficulty:"Easy", budget:300, skills:["ai","digital","coaching"], time:"flexible" },
  { id:74, name:"AI Content Generation Agency", tags:["ai","remote","digital","marketing"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["ai","digital","marketing"], time:"flexible" },
  { id:75, name:"Workflow Automation Expert", tags:["ai","remote","digital","tech"], cost:"N$0–500", difficulty:"Hard", budget:500, skills:["ai","tech","automation"], time:"flexible" },
  { id:76, name:"AI Video Creation Service", tags:["ai","remote","digital","creative"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["ai","video","creative"], time:"flexible" },

  // ── PRINT-ON-DEMAND ──────────────────────────────────────────────────────────
  { id:77, name:"Custom T-Shirt Design & POD", tags:["print","ecommerce","remote","creative"], cost:"N$0–500", difficulty:"Easy", budget:500, skills:["design","ecommerce","creative"], time:"flexible" },
  { id:78, name:"Personalized Mugs & Drinkware POD", tags:["print","ecommerce","remote"], cost:"N$300–1000", difficulty:"Easy", budget:1000, skills:["design","ecommerce"], time:"flexible" },
  { id:79, name:"Custom Phone Cases POD", tags:["print","ecommerce","remote"], cost:"N$200–800", difficulty:"Easy", budget:800, skills:["design","ecommerce"], time:"flexible" },
  { id:80, name:"Personalized Gifts & Merchandise", tags:["print","ecommerce","local","creative"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["design","ecommerce","creative"], time:"flexible" },

  // ── AFFILIATE MARKETING ──────────────────────────────────────────────────────
  { id:81, name:"Affiliate Marketing via TikTok", tags:["marketing","remote","digital","sales"], cost:"N$0–200", difficulty:"Medium", budget:200, skills:["social media","marketing","sales"], time:"flexible" },
  { id:82, name:"Amazon Associates & Affiliates", tags:["marketing","remote","digital","sales"], cost:"N$0–100", difficulty:"Easy", budget:100, skills:["marketing","social media"], time:"flexible" },
  { id:83, name:"Affiliate Marketing Coach", tags:["coaching","remote","digital","marketing"], cost:"N$0–500", difficulty:"Hard", budget:500, skills:["coaching","marketing","digital"], time:"flexible" },
  { id:84, name:"WhatsApp Product Promotions", tags:["marketing","local","sales","digital"], cost:"N$0–100", difficulty:"Easy", budget:100, skills:["sales","social media"], time:"flexible" },

  // ── DROPSERVICING ────────────────────────────────────────────────────────────
  { id:85, name:"Logo Design Dropservicing", tags:["dropservice","remote","digital","creative"], cost:"N$0–500", difficulty:"Medium", budget:500, skills:["design","sales","coaching"], time:"flexible" },
  { id:86, name:"Website Building Dropservice", tags:["dropservice","remote","digital","tech"], cost:"N$500–2000", difficulty:"Hard", budget:2000, skills:["tech","sales","design"], time:"flexible" },
  { id:87, name:"Video Editing Dropservice", tags:["dropservice","remote","digital","creative"], cost:"N$0–500", difficulty:"Medium", budget:500, skills:["video","sales","creative"], time:"flexible" },
  { id:88, name:"Social Media Dropservice", tags:["dropservice","remote","digital","marketing"], cost:"N$0–500", difficulty:"Medium", budget:500, skills:["social media","sales","marketing"], time:"flexible" },

  // ── TOURISM & GUIDING ────────────────────────────────────────────────────────
  { id:89, name:"Local Tour Guide & Excursions", tags:["tourism","local","service"], cost:"N$200–1000", difficulty:"Medium", budget:1000, skills:["hospitality","communication","local knowledge"], time:"flexible" },
  { id:90, name:"Safari & Wildlife Tour Guiding", tags:["tourism","local","service"], cost:"N$1000–5000", difficulty:"Medium", budget:5000, skills:["tourism","communication","nature"], time:"flexible" },
  { id:91, name:"Travel Planning & Consultation", tags:["tourism","remote","service","coaching"], cost:"N$0–500", difficulty:"Easy", budget:500, skills:["travel","coaching","communication"], time:"flexible" },
  { id:92, name:"Airbnb Host & Property Mgmt", tags:["tourism","property","local","service"], cost:"N$1000–5000", difficulty:"Medium", budget:5000, skills:["hospitality","communication","business"], time:"flexible" },

  // ── CAR RENTAL & TUK-TUK SERVICE ──────────────────────────────────────────────
  { id:93, name:"Car Rental Business", tags:["transport","local","service"], cost:"N$5000–20000", difficulty:"Hard", budget:20000, skills:["business","communication","driving"], time:"flexible" },
  { id:94, name:"Tuk-Tuk Rental Service", tags:["transport","local","service"], cost:"N$2000–8000", difficulty:"Medium", budget:8000, skills:["driving","business","hospitality"], time:"flexible" },
  { id:95, name:"Ride-Share Driver", tags:["transport","local","service"], cost:"N$1000–5000", difficulty:"Easy", budget:5000, skills:["driving","customer service"], time:"flexible" },
  { id:96, name:"Tourist Transport & Airport Shuttles", tags:["transport","local","tourism","service"], cost:"N$2000–8000", difficulty:"Medium", budget:8000, skills:["driving","hospitality","communication"], time:"flexible" },

  // ── SOLAR & RENEWABLE ENERGY ─────────────────────────────────────────────────
  { id:97, name:"Solar Panel Installation", tags:["energy","local","service","tech"], cost:"N$5000–15000", difficulty:"Hard", budget:15000, skills:["solar","tech","electrical"], time:"flexible" },
  { id:98, name:"Solar Energy Consultant", tags:["energy","local","coaching","tech"], cost:"N$0–1000", difficulty:"Medium", budget:1000, skills:["solar","coaching","tech"], time:"flexible" },
  { id:99, name:"Inverter & Battery Sales", tags:["energy","sales","local","ecommerce"], cost:"N$2000–10000", difficulty:"Medium", budget:10000, skills:["sales","tech","business"], time:"flexible" },
  { id:100, name:"Solar Maintenance & Repair", tags:["energy","local","service","tech"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["solar","tech","service"], time:"flexible" },

  // ── WATER PURIFICATION & DELIVERY ────────────────────────────────────────────
  { id:101, name:"Water Purification & Reselling", tags:["water","local","service","sales"], cost:"N$1000–5000", difficulty:"Medium", budget:5000, skills:["business","sales","service"], time:"flexible" },
  { id:102, name:"Water Delivery Service", tags:["water","local","transport","service"], cost:"N$500–2000", difficulty:"Easy", budget:2000, skills:["driving","customer service"], time:"flexible" },
  { id:103, name:"Water Tank Installation & Sales", tags:["water","local","service","sales"], cost:"N$2000–8000", difficulty:"Medium", budget:8000, skills:["sales","service","business"], time:"flexible" },
  { id:104, name:"Borehole Drilling Consultation", tags:["water","local","service","coaching"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["coaching","business","technical"], time:"flexible" },

  // ── UGC CREATOR (User Generated Content) ────────────────────────────────────
  { id:105, name:"UGC Video Creator for Brands", tags:["ugc","remote","creative","digital"], cost:"N$500–2000", difficulty:"Easy", budget:2000, skills:["video","creative","social media"], time:"flexible" },
  { id:106, name:"Product Review Creator", tags:["ugc","remote","creative","digital"], cost:"N$0–500", difficulty:"Easy", budget:500, skills:["video","creative","communication"], time:"flexible" },
  { id:107, name:"UGC Coaching Agency", tags:["ugc","remote","coaching","digital"], cost:"N$0–500", difficulty:"Medium", budget:500, skills:["coaching","video","digital"], time:"flexible" },
  { id:108, name:"Brand Testimonial Videos", tags:["ugc","remote","creative","video"], cost:"N$500–2000", difficulty:"Easy", budget:2000, skills:["video","creative","acting"], time:"flexible" },

  // ── VOICEOVER ARTIST ─────────────────────────────────────────────────────────
  { id:109, name:"Voiceover Artist for Ads & Videos", tags:["voiceover","remote","creative","audio"], cost:"N$200–1000", difficulty:"Medium", budget:1000, skills:["audio","voice","creative"], time:"flexible" },
  { id:110, name:"Audiobook Narrator", tags:["voiceover","remote","creative","audio"], cost:"N$500–3000", difficulty:"Medium", budget:3000, skills:["audio","reading","creative"], time:"flexible" },
  { id:111, name:"Podcast Guest & Speaker", tags:["voiceover","remote","creative","audio"], cost:"N$0–500", difficulty:"Medium", budget:500, skills:["audio","communication","creative"], time:"flexible" },
  { id:112, name:"IVR & Phone System Voiceovers", tags:["voiceover","remote","audio","tech"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["audio","voice","tech"], time:"flexible" },

  // ── NOTION & CANVA TEMPLATES ─────────────────────────────────────────────────
  { id:113, name:"Notion Template Creator & Seller", tags:["digital","remote","creative","passive"], cost:"N$0–300", difficulty:"Easy", budget:300, skills:["design","digital","creative"], time:"flexible" },
  { id:114, name:"Canva Template Design & Sales", tags:["design","remote","creative","passive"], cost:"N$0–200", difficulty:"Easy", budget:200, skills:["design","creative"], time:"flexible" },
  { id:115, name:"Digital Planner & Workbook Creator", tags:["digital","remote","creative","passive"], cost:"N$300–1000", difficulty:"Easy", budget:1000, skills:["design","creative","digital"], time:"flexible" },
  { id:116, name:"Printable & Digital Asset Store", tags:["digital","remote","ecommerce","passive"], cost:"N$500–2000", difficulty:"Medium", budget:2000, skills:["design","ecommerce","creative"], time:"flexible" },

  // ── EVENT DJ & SOUND HIRE ────────────────────────────────────────────────────
  { id:117, name:"Event DJ & Music Service", tags:["events","local","service","entertainment"], cost:"N$2000–8000", difficulty:"Medium", budget:8000, skills:["music","entertainment","communication"], time:"weekends" },
  { id:118, name:"Sound System & Equipment Rental", tags:["events","local","service"], cost:"N$1000–5000", difficulty:"Medium", budget:5000, skills:["tech","business","service"], time:"flexible" },
  { id:119, name:"Wedding DJ & Entertainment", tags:["events","local","service","entertainment"], cost:"N$2000–8000", difficulty:"Medium", budget:8000, skills:["music","entertainment","hospitality"], time:"weekends" },
  { id:120, name:"Event Sound Engineering", tags:["events","local","service","tech"], cost:"N$1000–5000", difficulty:"Hard", budget:5000, skills:["audio","tech","service"], time:"weekends" },
];

const DIFFICULTY_STEPS = {
  "Easy": [
    "Research your target market and local demand",
    "Gather minimal startup tools/materials",
    "Set your pricing based on local competitors",
    "Promote via WhatsApp status & Facebook groups",
    "Deliver your first service to 3 pilot customers"
  ],
  "Medium": [
    "Take a short online course or watch YouTube tutorials",
    "Create a simple portfolio or sample work",
    "Register informally or get required permits if needed",
    "Set up a basic social media presence",
    "Price competitively and ask for referrals after each job"
  ],
  "Hard": [
    "Invest in formal training or certification",
    "Build a professional portfolio & online presence",
    "Network with industry professionals",
    "Start small, reinvest profits to scale",
    "Track finances from day one"
  ]
};

const SEVEN_DAY = [
  "Day 1: Research & validate — talk to 5 potential customers",
  "Day 2: Set up your tools, workspace & supplies",
  "Day 3: Create your first sample or offering",
  "Day 4: Price your service & build a simple menu/portfolio",
  "Day 5: Post on WhatsApp, Facebook & ask family to share",
  "Day 6: Reach out directly to 10 potential clients",
  "Day 7: Complete your first paid gig & collect a testimonial"
];

// ── Score & Match ────────────────────────────────────────────────────────────
function scoreHustle(hustle, answers) {
  let score = 0;
  const skillLower = (answers.skills || "").toLowerCase();
  const budgetNum = parseInt(answers.budget) || 0;
  const time = answers.time || "";

  // beauty keyword boost
  const beautyKeywords = ["beauty","nail","nails","lash","lashes","makeup","hair","skin","skincare","salon","wax","massage"];
  const hustleBeauty = hustle.tags.includes("beauty") || hustle.skills.some(s => beautyKeywords.includes(s));
  const answerBeauty = beautyKeywords.some(k => skillLower.includes(k));
  if (answerBeauty && hustleBeauty) score += 4;

  // coaching keyword boost
  const coachKeywords = ["coach","coaching","teach","teaching","mentor","training","tutor"];
  const hustleCoach = hustle.tags.includes("coaching") || hustle.tags.includes("education");
  const answerCoach = coachKeywords.some(k => skillLower.includes(k));
  if (answerCoach && hustleCoach) score += 4;

  // digital keyword boost
  const digitalKeywords = ["digital","social","online","tech","coding","computer","design","video","content","marketing","ai","prompt","automation"];
  const hustleDigital = hustle.tags.includes("digital") || hustle.tags.includes("tech") || hustle.tags.includes("remote") || hustle.tags.includes("ai");
  const answerDigital = digitalKeywords.some(k => skillLower.includes(k));
  if (answerDigital && hustleDigital) score += 3;

  // sales keyword boost
  const salesKeywords = ["sales","selling","sell","resell","import","ecommerce","shop","store","trade","dropship","affiliate"];
  const hustleSales = hustle.tags.includes("sales") || hustle.tags.includes("ecommerce") || hustle.tags.includes("dropservice");
  const answerSales = salesKeywords.some(k => skillLower.includes(k));
  if (answerSales && hustleSales) score += 3;

  // tourism keyword boost
  const tourismKeywords = ["tour","tourism","travel","guide","safari","host","airbnb"];
  const hustleTourism = hustle.tags.includes("tourism");
  const answerTourism = tourismKeywords.some(k => skillLower.includes(k));
  if (answerTourism && hustleTourism) score += 3;

  // energy keyword boost
  const energyKeywords = ["solar","energy","electric","power","water","clean"];
  const hustleEnergy = hustle.tags.includes("energy") || hustle.tags.includes("water");
  const answerEnergy = energyKeywords.some(k => skillLower.includes(k));
  if (answerEnergy && hustleEnergy) score += 3;

  // creative keyword boost
  const creativeKeywords = ["creative","art","music","video","ugc","voiceover","podcast","dj","entertainment"];
  const hustleCreative = hustle.tags.includes("creative") || hustle.tags.includes("ugc") || hustle.tags.includes("voiceover") || hustle.tags.includes("events");
  const answerCreative = creativeKeywords.some(k => skillLower.includes(k));
  if (answerCreative && hustleCreative) score += 3;

  if (hustle.skills.some(s => skillLower.includes(s))) score += 3;
  if (budgetNum >= hustle.budget) score += 2;
  if (hustle.time === time || hustle.time === "flexible") score += 2;
  if (answers.goal && hustle.tags.includes(answers.goal)) score += 2;
  if (answers.location === "online" && hustle.tags.includes("remote")) score += 1;
  if (answers.location === "local" && hustle.tags.includes("local")) score += 1;
  return score;
}

function getTop5(answers) {
  return [...HUSTLES]
    .map(h => ({ ...h, score: scoreHustle(h, answers) }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);
}

// ── Storage helpers ──────────────────────────────────────────────────────────
const DB_KEY = "hustlematch_users";
function getUsers() { try { return JSON.parse(localStorage.getItem(DB_KEY) || "[]"); } catch { return []; } }
function saveUsers(u) { localStorage.setItem(DB_KEY, JSON.stringify(u)); }

// ── Styles ───────────────────────────────────────────────────────────────────
const G = {
  bg: "#FFFFFF",          // white background
  surface: "#F8F8F8",     // light grey surface
  card: "#F5F5F5",        // light card background
  border: "#E0E0E0",      // light border
  accent: "#C9A84C",      // primary gold
  accent2: "#E8C97A",     // lighter gold highlight
  accentDark: "#8B6914",  // deep gold for backgrounds
  text: "#1A1A1A",        // dark text for white bg
  muted: "#666666",       // muted dark grey
  danger: "#C0392B",      // red for danger
  white: "#FFFFFF",
  black: "#000000",
};

const css = `
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@600;700;800&family=Outfit:wght@300;400;500;600&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:${G.bg};color:${G.text};font-family:'Outfit',sans-serif;min-height:100vh}
  ::-webkit-scrollbar{width:6px}::-webkit-scrollbar-track{background:${G.surface}}::-webkit-scrollbar-thumb{background:#3A3420;border-radius:3px}
  .syne{font-family:'Poppins',sans-serif}
  button{cursor:pointer;font-family:'Outfit',sans-serif}
  input,select,textarea{font-family:'Outfit',sans-serif}
  @keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.6}}
  @keyframes spin{to{transform:rotate(360deg)}}
  .fadeUp{animation:fadeUp .5s ease both}
  .fadeUp1{animation:fadeUp .5s .1s ease both}
  .fadeUp2{animation:fadeUp .5s .2s ease both}
  .fadeUp3{animation:fadeUp .5s .3s ease both}
`;

// ── Shared Components ─────────────────────────────────────────────────────────
function Btn({ children, onClick, variant = "primary", style = {}, disabled }) {
  const base = {
    padding: "12px 24px", borderRadius: 10, fontWeight: 600, fontSize: 15,
    border: "none", transition: "all .2s", cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? .5 : 1, ...style
  };
  const variants = {
    primary: { background: `linear-gradient(135deg, ${G.accent}, ${G.accent2})`, color: G.black, fontWeight: 700 },
    outline: { background: "transparent", color: G.accent, border: `1.5px solid ${G.accent}` },
    danger: { background: G.danger, color: "#fff" },
    ghost: { background: "transparent", color: G.muted, border: `1px solid ${G.border}` },
    gold: { background: `linear-gradient(135deg, ${G.accent}, ${G.accent2})`, color: G.black, fontWeight: 700 },
  };
  return <button onClick={onClick} disabled={disabled} style={{ ...base, ...variants[variant] }}>{children}</button>;
}

function Card({ children, style = {} }) {
  return <div style={{ background: G.card, border: `1px solid ${G.border}`, borderRadius: 16, padding: 24, ...style }}>{children}</div>;
}

function Badge({ label, color = G.accent }) {
  return <span style={{ background: color + "22", color, border: `1px solid ${color}44`, borderRadius: 20, padding: "3px 12px", fontSize: 12, fontWeight: 600 }}>{label}</span>;
}

function Tag({ children }) {
  return <span style={{ background: G.surface, color: G.muted, border: `1px solid ${G.border}`, borderRadius: 6, padding: "2px 8px", fontSize: 11, marginRight: 4 }}>{children}</span>;
}

// ── NAV ───────────────────────────────────────────────────────────────────────
function Nav({ page, setPage, user }) {
  return (
    <nav style={{ background: G.white, borderBottom: `2px solid ${G.accent}`, padding: "0 20px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 72, position: "sticky", top: 0, zIndex: 100, boxShadow: `0 2px 12px rgba(0,0,0,.08)` }}>
      <img
        src="/mnt/user-data/uploads/1FDBA697-382D-4255-9CCB-1B957BFA92D8.png"
        alt="HustleMatch Namibia"
        onClick={() => setPage("home")}
        style={{ height: 56, cursor: "pointer", objectFit: "contain" }}
        onError={e => { e.target.style.display="none"; e.target.nextSibling.style.display="flex"; }}
      />
      <span className="syne" onClick={() => setPage("home")} style={{ display: "none", cursor: "pointer", fontWeight: 800, fontSize: 18, color: G.accent }}>
        HUSTLE <span style={{ color: G.text }}>MATCH</span> <span style={{ fontSize: 12, color: G.muted, fontWeight: 500, display: "block", lineHeight: 1.2 }}>Namibia<br/><span style={{ fontSize: 10, fontWeight: 400, color: "#999999" }}>By Picasso</span></span>
      </span>
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        {user?.approved && <Btn variant="outline" onClick={() => setPage("quiz")} style={{ padding: "8px 16px", fontSize: 13 }}>Take Quiz</Btn>}
        {user?.role === "admin" && <Btn variant="ghost" onClick={() => setPage("admin")} style={{ padding: "8px 16px", fontSize: 13 }}>Admin</Btn>}
        {!user && <Btn variant="primary" onClick={() => setPage("pay")} style={{ padding: "8px 18px", fontSize: 13 }}>Get Access – N$50</Btn>}
        {user && !user.approved && <Badge label="⏳ Pending" color={G.accent} />}
      </div>
    </nav>
  );
}

// ── PROMO TICKER ─────────────────────────────────────────────────────────────
const promoCss = `
  @keyframes ticker {
    0% { transform: translateX(100vw); }
    100% { transform: translateX(-100%); }
  }
  .ticker-wrap {
    overflow: hidden;
    background: linear-gradient(90deg, #1A1A1A, #2A2A2A, #1A1A1A);
    border-bottom: 2px solid #C9A84C;
    padding: 9px 0;
    white-space: nowrap;
  }
  .ticker-text {
    display: inline-block;
    animation: ticker 16s linear infinite;
    font-family: 'Poppins', sans-serif;
    font-weight: 700;
    font-size: 14px;
    color: #C9A84C;
    letter-spacing: 1.5px;
  }
  .ticker-text .old { text-decoration: line-through; opacity: .6; margin-right: 6px; color: #999999; }
  .ticker-text .new { color: #FFD700; font-size: 16px; margin: 0 6px; font-weight: 800; }
  .ticker-text .sep { margin: 0 32px; opacity: .4; }
`;

function PromoBanner() {
  const { useEffect } = window.React || {};
  if (typeof document !== "undefined") {
    const s = document.getElementById("promo-css");
    if (!s) {
      const el = document.createElement("style");
      el.id = "promo-css";
      el.textContent = promoCss;
      document.head.appendChild(el);
    }
  }
  const msg = (
    <>
      🔥 <span className="old">Was N$100</span> — Now <span className="new">N$50</span> (Limited Time Offer!)
      <span className="sep">✦</span>
      🔥 <span className="old">Was N$100</span> — Now <span className="new">N$50</span> (Limited Time Offer!)
      <span className="sep">✦</span>
      🔥 <span className="old">Was N$100</span> — Now <span className="new">N$50</span> (Limited Time Offer!)
    </>
  );
  return (
    <div className="ticker-wrap">
      <span className="ticker-text">{msg}</span>
    </div>
  );
}

// ── HOME ──────────────────────────────────────────────────────────────────────
function Home({ setPage }) {
  const features = [
    { icon: "🎯", title: "Personalised Matches", desc: "Answer a few simple questions and get hustle ideas built for your skills, time & budget." },
    { icon: "📋", title: "Step-by-Step Guidance", desc: "Every match includes a clear action plan and tips so you can start right away." },
    { icon: "🇳🇦", title: "Opportunities for Everyone, Everywhere", desc: "Find side hustles that work across Namibia and globally — regardless of location." },
  ];

  return (
    <div style={{ maxWidth: 860, margin: "0 auto" }}>
      <PromoBanner />

      <div style={{ padding: "52px 24px 0" }}>
        {/* HERO */}
        <div className="fadeUp" style={{ textAlign: "center", marginBottom: 52 }}>
          <div style={{ display: "inline-block", background: G.accent + "18", border: `2px solid ${G.accent}`, borderRadius: 30, padding: "6px 20px", fontSize: 13, color: G.accent, marginBottom: 20, fontWeight: 700, letterSpacing: 1, textTransform: "uppercase" }}>
            ✦ HustleMatch Namibia
          </div>

          <h1 className="syne" style={{ fontSize: "clamp(34px,6vw,60px)", fontWeight: 800, lineHeight: 1.1, marginBottom: 16, color: G.text }}>
            Find Your Perfect<br /><span style={{ background: `linear-gradient(135deg, ${G.accent}, ${G.accent2})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Side Hustle</span>
          </h1>

          {/* SUBHEADLINE */}
          <p style={{ fontSize: 17, color: G.text, maxWidth: 560, margin: "0 auto 10px", lineHeight: 1.75, fontWeight: 400 }}>
            Answer a few simple questions and get <strong style={{ color: G.accent }}>3 side hustle ideas</strong> matched to your skills, time, and budget — with step-by-step guidance on how to start.
          </p>
          <p style={{ fontSize: 13, color: G.accent, maxWidth: 480, margin: "0 auto 32px", lineHeight: 1.6 }}>
            ⚠️ Access is valid for <strong>one session only</strong>. You'll need to pay again if you want new results later.
          </p>

          {/* PRICE SECTION */}
          <div style={{ background: G.white, border: `2px solid ${G.accent}`, borderRadius: 18, padding: "28px 28px 24px", maxWidth: 400, margin: "0 auto 28px", textAlign: "left", boxShadow: `0 8px 32px rgba(0,0,0,.08)` }}>
            <p style={{ fontSize: 11, color: G.accent, fontWeight: 700, marginBottom: 14, textTransform: "uppercase", letterSpacing: 2 }}>— What you unlock —</p>
            {[
              { icon: "🔓", text: "Unlock 120+ Side Hustle Ideas" },
              { icon: "💡", text: "Get Your 3 Best Matches" },
              { icon: "📍", text: "Works in Namibia & Worldwide" },
            ].map((item, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 13 }}>
                <span style={{ fontSize: 20 }}>{item.icon}</span>
                <span style={{ fontSize: 15, color: G.text, fontWeight: 500 }}>{item.text}</span>
              </div>
            ))}
            <div style={{ marginTop: 20, paddingTop: 18, borderTop: `2px solid ${G.border}`, textAlign: "center" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 10, marginBottom: 6 }}>
                <span style={{ fontSize: 14, color: G.muted, textDecoration: "line-through" }}>N$100</span>
                <span style={{ background: G.accent, color: G.black, fontSize: 10, fontWeight: 800, padding: "4px 12px", borderRadius: 20, letterSpacing: 1, textTransform: "uppercase" }}>Limited Time</span>
              </div>
              <p className="syne" style={{ fontSize: 26, fontWeight: 800, background: `linear-gradient(135deg, ${G.accent}, ${G.accent2})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", marginBottom: 0 }}>
                👉 Only N$50 once-off
              </p>
            </div>
          </div>

          {/* CTA */}
          <Btn onClick={() => setPage("pay")} style={{ fontSize: 17, padding: "16px 40px", borderRadius: 14, fontWeight: 800, letterSpacing: .3, boxShadow: `0 4px 20px rgba(201,168,76,.35)` }}>
            Get My 3 Hustle Ideas →
          </Btn>
          <p style={{ marginTop: 14, fontSize: 12, color: G.muted }}>One-time payment · No subscription · Manual approval 06:00–21:00 daily</p>
        </div>

        {/* CATEGORIES SHOWCASE */}
        <Card className="fadeUp1" style={{ marginBottom: 40, background: G.card, border: `2px solid ${G.accent}`, position: "relative", overflow: "hidden", textAlign: "center" }}>
          {/* N$ Watermark */}
          <div style={{ position: "absolute", top: "50%", right: "-40px", transform: "translateY(-50%) rotate(-15deg)", fontSize: 180, fontWeight: 800, color: G.accent + "08", zIndex: 0 }}>N$</div>
          
          <div style={{ position: "relative", zIndex: 1 }}>
            <h2 className="syne" style={{ fontWeight: 700, fontSize: 20, marginBottom: 18, color: G.text }}>120+ Hustle Ideas Across All Categories:</h2>
            <p style={{ fontSize: 16, color: G.text, lineHeight: 2.2, marginBottom: 0, fontWeight: 500 }}>
              💻 Digital Services  💄 Beauty Industry  ✈️ Tourism & Travel  ⚡ Energy & Water<br/>
              🛍️ Sales & Ecommerce  🎯 Coaching & Education  🚗 Transport & Mobility  🎬 Creative & Media  <span style={{ color: G.accent, fontWeight: 700, fontSize: 18 }}>& More...</span>
            </p>
          </div>
        </Card>

        {/* FEATURE CARDS */}
        <div className="fadeUp1" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(190px,1fr))", gap: 14, marginBottom: 52 }}>
          {features.map((f, i) => (
            <Card key={i} style={{ textAlign: "center", border: `1px solid ${G.border}`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
              <div style={{ fontSize: f.icon === "🇳🇦" ? 48 : 30, marginBottom: 10, lineHeight: 1 }}>{f.icon}</div>
              <h3 className="syne" style={{ fontWeight: 700, fontSize: 14, marginBottom: 6, color: G.text }}>{f.title}</h3>
              <p style={{ fontSize: 12, color: G.muted, lineHeight: 1.6 }}>{f.desc}</p>
            </Card>
          ))}
        </div>

        {/* BOTTOM CTA */}
        <Card className="fadeUp2" style={{ textAlign: "center", background: `linear-gradient(135deg, ${G.card}, ${G.surface})`, border: `2px solid ${G.accent}`, marginBottom: 48, boxShadow: `0 4px 16px rgba(0,0,0,.08)` }}>
          <h2 className="syne" style={{ fontWeight: 700, fontSize: 20, marginBottom: 8, color: G.text }}>Ready to find your hustle?</h2>
          <p style={{ color: G.muted, marginBottom: 20, fontSize: 14 }}>Join Namibians already discovering their income potential.</p>
          <Btn onClick={() => setPage("pay")} style={{ fontSize: 16, padding: "13px 32px", fontWeight: 800, boxShadow: `0 4px 12px rgba(201,168,76,.2)` }}>Get My 3 Hustle Ideas →</Btn>
        </Card>

        <p style={{ textAlign: "center", marginBottom: 48, fontSize: 12, color: G.muted, lineHeight: 1.8 }}>
          ⚠️ <strong style={{ color: G.text }}>Disclaimer:</strong> HustleMatch provides general ideas and guidance only. Success depends entirely on your personal effort, commitment, and execution — results are not automatic or guaranteed. This is not professional financial or business advice. Individual results will vary.
        </p>
      </div>
    </div>
  );
}

// ── PAYMENT ───────────────────────────────────────────────────────────────────
function Payment({ setPage, setCurrentUser }) {
  const [step, setStep] = useState(1); // 1=info, 2=submitted
  const [form, setForm] = useState({ name: "", phone: "", ref: "" });
  const [err, setErr] = useState("");

  const PAYTODAY_URL = "https://admin.today.com.na/web/payments/0000000105QvOxsnSL81kxz5n5EikV4UiH0GvDEHrOj2Aa8vXIbUH1sS6W6k768354150cf1592c6a669c227f6cf73cf3763b0b/";

  function handleSubmit() {
    if (!form.name.trim() || !form.phone.trim() || !form.ref.trim()) {
      setErr("Please fill in all fields."); return;
    }
    const users = getUsers();
    const existing = users.find(u => u.phone === form.phone);
    if (existing) {
      if (existing.approved) {
        setCurrentUser(existing);
        setPage("quiz");
        return;
      }
      setStep(2); return;
    }
    const newUser = { id: Date.now(), name: form.name, phone: form.phone, ref: form.ref, approved: false, role: "user", submittedAt: new Date().toISOString(), usedAt: null };
    users.push(newUser);
    saveUsers(users);
    setCurrentUser(newUser);
    setStep(2);
  }

  if (step === 2) return (
    <div style={{ maxWidth: 520, margin: "80px auto", padding: "0 24px" }}>
      <Card className="fadeUp" style={{ textAlign: "center" }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>✅</div>
        <h2 className="syne" style={{ fontWeight: 800, fontSize: 22, marginBottom: 12 }}>Payment Submitted!</h2>
        <p style={{ color: G.muted, lineHeight: 1.8, fontSize: 15 }}>
          Thank you for your payment submission. Your access is <strong style={{ color: G.accent2 }}>pending manual approval</strong>.<br /><br />
          Payments are reviewed between <strong style={{ color: G.text }}>06:00 and 21:00 daily</strong>.<br /><br />
          You'll be notified on <strong style={{ color: G.text }}>{form.phone}</strong> once approved. Please check back or contact us via WhatsApp.
        </p>
        <div style={{ marginTop: 24, paddingTop: 24, borderTop: `1px solid ${G.border}` }}>
          <p style={{ fontSize: 13, color: G.muted }}>Already approved? Enter your phone number to access.</p>
          <Btn variant="outline" onClick={() => setStep(1)} style={{ marginTop: 12 }}>Check Access Status</Btn>
        </div>
      </Card>
    </div>
  );

  return (
    <div style={{ maxWidth: 520, margin: "60px auto", padding: "0 24px" }}>
      <div className="fadeUp" style={{ textAlign: "center", marginBottom: 32 }}>
        <h1 className="syne" style={{ fontWeight: 800, fontSize: 28 }}>Get Access</h1>
        <p style={{ color: G.muted, marginTop: 8 }}>One-time payment of N$50 for full access</p>
      </div>

      <Card className="fadeUp1" style={{ marginBottom: 20, background: `linear-gradient(135deg, #100E08, #1A1610)`, border: `1px solid ${G.accent}55` }}>
        <h3 className="syne" style={{ fontWeight: 700, marginBottom: 8, color: G.accent }}>💳 Step 1 — Pay N$50</h3>
        <p style={{ fontSize: 14, color: G.muted, lineHeight: 1.7, marginBottom: 16 }}>
          Click the button below to open PayToday. Use your <strong style={{ color: G.text }}>Full Name</strong> as the payment reference so we can verify your payment.
        </p>
        <Btn variant="gold" onClick={() => window.open(PAYTODAY_URL, "_blank")} style={{ width: "100%" }}>
          Open PayToday — Pay N$50 →
        </Btn>
      </Card>

      <Card className="fadeUp2">
        <h3 className="syne" style={{ fontWeight: 700, marginBottom: 20, color: G.text }}>📝 Step 2 — Submit Your Details</h3>
        {err && <p style={{ color: G.danger, fontSize: 13, marginBottom: 16 }}>{err}</p>}

        {[
          { label: "Full Name", key: "name", placeholder: "e.g. Maria Shikongo", type: "text" },
          { label: "Phone Number (WhatsApp)", key: "phone", placeholder: "e.g. 0812345678", type: "tel" },
          { label: "Payment Reference Used", key: "ref", placeholder: "Your full name as used on PayToday", type: "text" },
        ].map(f => (
          <div key={f.key} style={{ marginBottom: 18 }}>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 8, color: G.muted }}>{f.label}</label>
            <input
              type={f.type}
              placeholder={f.placeholder}
              value={form[f.key]}
              onChange={e => setForm({ ...form, [f.key]: e.target.value })}
              style={{ width: "100%", background: G.surface, border: `1px solid ${G.border}`, borderRadius: 8, padding: "12px 14px", color: G.text, fontSize: 14, outline: "none" }}
            />
          </div>
        ))}

        <Btn onClick={handleSubmit} style={{ width: "100%", marginTop: 8, padding: "14px" }}>Submit for Approval →</Btn>
        <p style={{ fontSize: 12, color: G.muted, textAlign: "center", marginTop: 16 }}>Approvals reviewed 06:00–21:00 daily. No access before approval.</p>
      </Card>
    </div>
  );
}

// ── QUIZ ──────────────────────────────────────────────────────────────────────
const QUESTIONS = [
  { id: "skills", label: "What are your top skills or interests?", type: "text", placeholder: "e.g. nails, coaching, social media, solar, travel, dj, voiceover, ugc..." },
  { id: "time", label: "When are you available to hustle?", type: "select", options: ["flexible","mornings","evenings","weekends","full-time","part-time"] },
  { id: "budget", label: "What's your starting budget? (N$)", type: "select", options: ["0","200","500","1000","2000","5000"] },
  { id: "location", label: "Where would you prefer to work?", type: "select", options: ["local","online","both"] },
  { id: "goal", label: "Which category interests you?", type: "select", options: ["digital","sales","beauty","coaching","tourism","transport","energy","creative"] },
  { id: "experience", label: "Your general work experience level?", type: "select", options: ["beginner","intermediate","experienced"] },
  { id: "people", label: "Do you prefer working with people?", type: "select", options: ["yes - love it","sometimes","no - prefer solo"] },
  { id: "phone", label: "Your phone number (for access verification)", type: "tel", placeholder: "e.g. 0812345678" },
];

function Quiz({ setPage, currentUser, setResults }) {
  const [q, setQ] = useState(0);
  const [answers, setAnswers] = useState({});
  const [val, setVal] = useState("");
  const [locked, setLocked] = useState(!currentUser?.approved);
  const [checkPhone, setCheckPhone] = useState("");
  const [checkErr, setCheckErr] = useState("");

  function checkAccess() {
    const users = getUsers();
    const u = users.find(x => x.phone === checkPhone);
    if (u?.approved) { setLocked(false); setCheckErr(""); }
    else if (u) setCheckErr("Your payment is still pending approval.");
    else setCheckErr("No account found. Please complete payment first.");
  }

  function next() {
    if (!val.trim()) return;
    const newAns = { ...answers, [QUESTIONS[q].id]: val };
    setAnswers(newAns);
    setVal("");
    if (q < QUESTIONS.length - 1) { setQ(q + 1); }
    else {
      const top5 = getTop5(newAns);
      setResults(top5);
      setPage("results");
    }
  }

  if (locked) return (
    <div style={{ maxWidth: 480, margin: "80px auto", padding: "0 24px" }}>
      <Card className="fadeUp" style={{ textAlign: "center" }}>
        <div style={{ fontSize: 40, marginBottom: 16 }}>🔒</div>
        <h2 className="syne" style={{ fontWeight: 800, fontSize: 22, marginBottom: 12 }}>Access Required</h2>
        <p style={{ color: G.muted, marginBottom: 24, lineHeight: 1.7 }}>You need an approved N$50 payment to take the quiz. Already paid? Enter your phone to verify access.</p>
        <input
          type="tel" placeholder="Your phone number" value={checkPhone}
          onChange={e => setCheckPhone(e.target.value)}
          style={{ width: "100%", background: G.surface, border: `1px solid ${G.border}`, borderRadius: 8, padding: "12px 14px", color: G.text, fontSize: 14, outline: "none", marginBottom: 12 }}
        />
        {checkErr && <p style={{ color: G.danger, fontSize: 13, marginBottom: 12 }}>{checkErr}</p>}
        <Btn onClick={checkAccess} style={{ width: "100%", marginBottom: 12 }}>Check My Access</Btn>
        <Btn variant="outline" onClick={() => setPage("pay")} style={{ width: "100%" }}>Get Access – N$50</Btn>
      </Card>
    </div>
  );

  const curr = QUESTIONS[q];
  const pct = Math.round(((q) / QUESTIONS.length) * 100);

  return (
    <div style={{ maxWidth: 560, margin: "60px auto", padding: "0 24px" }}>
      <div className="fadeUp" style={{ marginBottom: 32 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <span style={{ fontSize: 13, color: G.muted }}>Question {q + 1} of {QUESTIONS.length}</span>
          <span style={{ fontSize: 13, color: G.accent, fontWeight: 600 }}>{pct}% complete</span>
        </div>
        <div style={{ background: G.border, borderRadius: 4, height: 4 }}>
          <div style={{ background: G.accent, width: `${pct}%`, height: 4, borderRadius: 4, transition: "width .4s" }} />
        </div>
      </div>

      <Card className="fadeUp1">
        <h2 className="syne" style={{ fontWeight: 700, fontSize: 20, marginBottom: 24, lineHeight: 1.4 }}>{curr.label}</h2>

        {curr.type === "select" ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {curr.options.map(o => (
              <button key={o} onClick={() => setVal(o)}
                style={{ background: val === o ? G.accent + "20" : G.surface, border: `1.5px solid ${val === o ? G.accent : G.border}`, borderRadius: 10, padding: "14px 18px", color: val === o ? G.accent : G.text, fontSize: 14, fontWeight: val === o ? 600 : 400, textAlign: "left", transition: "all .2s", cursor: "pointer", textTransform: "capitalize" }}>
                {o}
              </button>
            ))}
          </div>
        ) : (
          <input
            type={curr.type} placeholder={curr.placeholder} value={val}
            onChange={e => setVal(e.target.value)}
            onKeyDown={e => e.key === "Enter" && next()}
            style={{ width: "100%", background: G.surface, border: `1px solid ${G.border}`, borderRadius: 8, padding: "14px 16px", color: G.text, fontSize: 15, outline: "none" }}
          />
        )}

        <div style={{ marginTop: 24, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          {q > 0
            ? <Btn variant="ghost" onClick={() => { setQ(q - 1); setVal(""); }} style={{ padding: "10px 18px" }}>← Back</Btn>
            : <span />}
          <Btn onClick={next} disabled={!val.trim()}>
            {q === QUESTIONS.length - 1 ? "Get My Results →" : "Next →"}
          </Btn>
        </div>
      </Card>
    </div>
  );
}

// ── RESULTS ───────────────────────────────────────────────────────────────────
function Results({ results, setPage, currentUser }) {
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    if (currentUser && !currentUser.approved) return;
    if (currentUser) {
      const users = getUsers();
      const idx = users.findIndex(u => u.id === currentUser.id);
      if (idx >= 0) { users[idx].usedAt = new Date().toISOString(); saveUsers(users); }
    }
  }, []);

  if (!results || results.length === 0) {
    return (
      <div style={{ textAlign: "center", padding: 80 }}>
        <p style={{ color: G.muted }}>No results found. <span style={{ color: G.accent, cursor: "pointer" }} onClick={() => setPage("quiz")}>Take the quiz →</span></p>
      </div>
    );
  }

  const diffColor = { Easy: G.accent, Medium: G.accent2, Hard: G.danger };

  return (
    <div style={{ maxWidth: 720, margin: "0 auto", padding: "60px 24px" }}>
      <div className="fadeUp" style={{ textAlign: "center", marginBottom: 40 }}>
        <div style={{ fontSize: 40, marginBottom: 12 }}>🎉</div>
        <h1 className="syne" style={{ fontWeight: 800, fontSize: 28, marginBottom: 8 }}>Your Top 5 Hustles</h1>
        <p style={{ color: G.muted }}>Personalised based on your skills, time & budget. Click any card to see your full plan.</p>
      </div>

      {results.map((h, i) => (
        <div key={h.id} className={`fadeUp${Math.min(i, 3)}`} style={{ marginBottom: 16 }}>
          <Card style={{ cursor: "pointer", border: `1px solid ${expanded === h.id ? G.accent + "66" : G.border}`, transition: "all .2s" }}
            onClick={() => setExpanded(expanded === h.id ? null : h.id)}>
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <div style={{ background: G.accent + "20", color: G.accent, borderRadius: 12, width: 44, height: 44, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 18, flexShrink: 0, border: `1px solid ${G.accent}44` }}>#{i + 1}</div>
              <div style={{ flex: 1 }}>
                <h3 className="syne" style={{ fontWeight: 700, fontSize: 16, marginBottom: 6 }}>{h.name}</h3>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
                  <Badge label={`💰 ${h.cost}`} color={G.muted} />
                  <Badge label={h.difficulty} color={diffColor[h.difficulty]} />
                  {h.tags.slice(0, 2).map(t => <Tag key={t}>{t}</Tag>)}
                </div>
              </div>
              <span style={{ color: G.muted, fontSize: 20 }}>{expanded === h.id ? "▲" : "▼"}</span>
            </div>

            {expanded === h.id && (
              <div style={{ marginTop: 24, paddingTop: 20, borderTop: `1px solid ${G.border}` }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 24 }}>
                  <div>
                    <h4 style={{ fontWeight: 600, fontSize: 13, color: G.muted, marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>Getting Started</h4>
                    {(DIFFICULTY_STEPS[h.difficulty] || []).map((s, j) => (
                      <div key={j} style={{ display: "flex", gap: 10, marginBottom: 8, alignItems: "flex-start" }}>
                        <span style={{ color: G.accent, fontWeight: 700, flexShrink: 0 }}>0{j + 1}.</span>
                    <span style={{ fontSize: 13, color: G.text, lineHeight: 1.5 }}>{s}</span>
                      </div>
                    ))}
                  </div>
                  <div>
                    <h4 style={{ fontWeight: 600, fontSize: 13, color: G.muted, marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>7-Day Action Plan</h4>
                    {SEVEN_DAY.map((s, j) => (
                      <div key={j} style={{ display: "flex", gap: 10, marginBottom: 8, alignItems: "flex-start" }}>
                        <span style={{ color: G.accent2, fontWeight: 700, fontSize: 11, flexShrink: 0, marginTop: 2 }}>D{j + 1}</span>
                        <span style={{ fontSize: 12, color: G.muted, lineHeight: 1.5 }}>{s.replace(/^Day \d+: /, "")}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div style={{ background: G.surface, borderRadius: 10, padding: 16 }}>
                  <h4 style={{ fontWeight: 600, fontSize: 13, color: G.muted, marginBottom: 8, textTransform: "uppercase", letterSpacing: 1 }}>💡 Pro Tips</h4>
                  <ul style={{ paddingLeft: 18, fontSize: 13, color: G.text, lineHeight: 2 }}>
                    <li>Start small — validate with 3 paying customers before scaling.</li>
                    <li>Use WhatsApp Business to promote for free in Namibia.</li>
                    <li>Reinvest your first N$500 profit back into tools or marketing.</li>
                    <li>Network in local Facebook groups like "Namibia Buy & Sell".</li>
                  </ul>
                </div>
              </div>
            )}
          </Card>
        </div>
      ))}

      <div style={{ textAlign: "center", marginTop: 40, padding: "24px 0", borderTop: `1px solid ${G.border}` }}>
        <p style={{ fontSize: 12, color: G.muted, lineHeight: 1.8, marginBottom: 20 }}>
          ⚠️ <strong>Disclaimer:</strong> These recommendations are generated for informational purposes only. Your results depend entirely on your personal effort, dedication, and execution — success is never automatic. This is not professional financial, business, or legal advice. Always conduct your own research before starting any business venture.
        </p>
        <Btn variant="outline" onClick={() => setPage("quiz")} style={{ marginRight: 12 }}>Retake Quiz</Btn>
        <Btn variant="ghost" onClick={() => setPage("home")}>← Home</Btn>
      </div>
    </div>
  );
}

// ── ADMIN ─────────────────────────────────────────────────────────────────────
function Admin({ setPage }) {
  const [pw, setPw] = useState("");
  const [auth, setAuth] = useState(false);
  const [users, setUsersState] = useState([]);
  const [filter, setFilter] = useState("all");
  const ADMIN_PW = "hustleadmin2025";

  function login() {
    if (pw === ADMIN_PW) { setAuth(true); setUsersState(getUsers()); }
    else alert("Wrong password.");
  }

  function approve(id) {
    const u = getUsers().map(x => x.id === id ? { ...x, approved: true } : x);
    saveUsers(u); setUsersState(u);
  }

  function reject(id) {
    const u = getUsers().filter(x => x.id !== id);
    saveUsers(u); setUsersState(u);
  }

  function exportCSV() {
    const header = ["ID","Name","Phone","Ref","Approved","Submitted","Used"];
    const rows = users.map(u => [u.id, u.name, u.phone, u.ref, u.approved, u.submittedAt, u.usedAt || ""].join(","));
    const blob = new Blob([[header.join(","), ...rows].join("\n")], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "hustlematch_users.csv"; a.click();
  }

  const filtered = users.filter(u => filter === "all" ? true : filter === "approved" ? u.approved : !u.approved);
  const revenue = users.filter(u => u.approved).length * 50;

  if (!auth) return (
    <div style={{ maxWidth: 400, margin: "100px auto", padding: "0 24px" }}>
      <Card className="fadeUp" style={{ textAlign: "center" }}>
        <div style={{ fontSize: 40, marginBottom: 16 }}>🛡️</div>
        <h2 className="syne" style={{ fontWeight: 800, fontSize: 22, marginBottom: 20 }}>Admin Login</h2>
        <input type="password" placeholder="Admin password" value={pw} onChange={e => setPw(e.target.value)} onKeyDown={e => e.key === "Enter" && login()}
          style={{ width: "100%", background: G.surface, border: `1px solid ${G.border}`, borderRadius: 8, padding: "12px 14px", color: G.text, fontSize: 14, outline: "none", marginBottom: 16 }} />
        <Btn onClick={login} style={{ width: "100%" }}>Login</Btn>
      </Card>
    </div>
  );

  return (
    <div style={{ maxWidth: 960, margin: "0 auto", padding: "40px 24px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 32 }}>
        <h1 className="syne fadeUp" style={{ fontWeight: 800, fontSize: 24 }}>Admin Dashboard</h1>
        <div style={{ display: "flex", gap: 8 }}>
          <Btn variant="outline" onClick={exportCSV} style={{ padding: "8px 16px", fontSize: 13 }}>Export CSV</Btn>
          <Btn variant="ghost" onClick={() => setPage("home")} style={{ padding: "8px 16px", fontSize: 13 }}>← Exit</Btn>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 16, marginBottom: 32 }}>
        {[
          { label: "Total Users", val: users.length, color: G.text },
          { label: "Approved", val: users.filter(u => u.approved).length, color: G.accent },
          { label: "Pending", val: users.filter(u => !u.approved).length, color: G.accent2 },
          { label: "Revenue (est.)", val: `N$${revenue}`, color: G.accent },
        ].map((s, i) => (
          <Card key={i} style={{ textAlign: "center" }}>
            <div style={{ fontSize: 28, fontWeight: 800, color: s.color, fontFamily: "Syne" }}>{s.val}</div>
            <div style={{ fontSize: 12, color: G.muted, marginTop: 6 }}>{s.label}</div>
          </Card>
        ))}
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {["all", "pending", "approved"].map(f => (
          <button key={f} onClick={() => setFilter(f)}
            style={{ padding: "8px 18px", borderRadius: 8, border: `1px solid ${filter === f ? G.accent : G.border}`, background: filter === f ? G.accent + "20" : "transparent", color: filter === f ? G.accent : G.muted, fontSize: 13, cursor: "pointer", textTransform: "capitalize" }}>
            {f}
          </button>
        ))}
      </div>

      {filtered.length === 0 && <Card style={{ textAlign: "center", color: G.muted }}>No users found.</Card>}
      {filtered.map(u => (
        <Card key={u.id} style={{ marginBottom: 12, display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
          <div style={{ flex: 1, minWidth: 200 }}>
            <div style={{ fontWeight: 600, fontSize: 15 }}>{u.name}</div>
            <div style={{ fontSize: 13, color: G.muted }}>📱 {u.phone} · Ref: {u.ref}</div>
            <div style={{ fontSize: 12, color: G.muted, marginTop: 4 }}>{new Date(u.submittedAt).toLocaleString()}</div>
          </div>
          <div>
            {u.approved ? <Badge label="✅ Approved" color={G.accent} /> : <Badge label="⏳ Pending" color={G.accent2} />}
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            {!u.approved && <Btn variant="primary" onClick={() => approve(u.id)} style={{ padding: "8px 14px", fontSize: 13 }}>Approve</Btn>}
            <Btn variant="danger" onClick={() => reject(u.id)} style={{ padding: "8px 14px", fontSize: 13 }}>Remove</Btn>
          </div>
        </Card>
      ))}
      <p style={{ fontSize: 12, color: G.muted, marginTop: 20 }}>Admin password: <code style={{ color: G.accent }}>hustleadmin2025</code> — change before going live.</p>
    </div>
  );
}

// ── APP ───────────────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState("home");
  const [currentUser, setCurrentUser] = useState(null);
  const [results, setResults] = useState(null);

  useEffect(() => {
    const style = document.createElement("style");
    style.textContent = css;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  const pages = { home: Home, pay: Payment, quiz: Quiz, results: Results, admin: Admin };
  const Page = pages[page] || Home;

  return (
    <div style={{ background: G.bg, minHeight: "100vh" }}>
      <Nav page={page} setPage={setPage} user={currentUser} />
      <Page setPage={setPage} currentUser={currentUser} setCurrentUser={setCurrentUser} results={results} setResults={setResults} />
    </div>
  );
}
